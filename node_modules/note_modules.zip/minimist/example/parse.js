var argv = require('../')(process.argv.slice(2));
console.dir(argv);
