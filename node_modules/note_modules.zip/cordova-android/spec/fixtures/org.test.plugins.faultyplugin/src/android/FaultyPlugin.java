./org.test.plugins.faultyplugin/src/android/org.test.plugins.faultyplugin.java
