./org.test.plugins.dummyplugin/src/android/DummyPlugin2.java
